/*
 *
 *  file: spmacros.h
 *
 *  Define some commonly used macros for data reading.
 *
 */
