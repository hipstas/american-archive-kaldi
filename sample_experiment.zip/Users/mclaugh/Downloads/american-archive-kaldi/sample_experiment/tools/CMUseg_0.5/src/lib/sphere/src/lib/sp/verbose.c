
#include <stdio.h>
#define SPHERE_LIBRARY_CODE
#include <sp/sphere.h>

int sp_verbose = 0;

void sp_set_verbose(int n)
{
    sp_verbose = n;
}

